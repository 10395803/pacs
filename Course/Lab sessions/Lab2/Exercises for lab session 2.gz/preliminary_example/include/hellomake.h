// hellomake.h
// --------------------------

#ifdef __cplusplus
extern "C"{
#endif

void myPrintHelloMake (void);


#ifdef __cplusplus
}
#endif
