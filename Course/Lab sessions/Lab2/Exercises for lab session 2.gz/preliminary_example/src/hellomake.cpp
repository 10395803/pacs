// hellomake.cpp
// --------------------------

#include <hellomake.h>

int main() 
{
  // call function from other file
  myPrintHelloMake ();

  return(0);
}
